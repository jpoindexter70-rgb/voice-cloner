# AI Voice Cloning Studio 2.1.0 — source handoff

This is an editable source snapshot of the independent `Studio-2.0` application, whose health endpoint/build label reports **2.1.0**. The internal folder, launcher names, some titles and original README still say Studio 2.0; they have been preserved. This is not a snapshot of an unseen Family AI Voice Cloner Pro v0.3.0/3.0 Windows installation.

Source commit: **dbcfac6946f2e1122d8587f605c8c49a02226dc0** (`studio-2-family-library`).

All 74 tracked project files are copied byte-for-byte. No application source, features, dependencies, installers or running services were changed or rebuilt to create this transfer. This top-level README, `DEPENDENCY-SNAPSHOT.json`, `LOCAL-CONFIGURATION.template.txt` and `SOURCE-MANIFEST.json` are transfer documentation only. The original `Studio-2.0/README.md` is retained unchanged. The manifest supplies SHA-256 and size for every transferred original file.

Excluded: neural weights/checkpoints, personal recordings/profiles, generated audio, backups, virtual environments, caches, Git metadata, credentials, existing compiled/generated ZIPs and temporary logs. Original test code, licenses, dependency files, all static assets and the legacy library-only HTML companion are included. The original Voice Control Room outside `Studio-2.0` is a different app and is not part of this version.

## Project map and request coverage

- `Studio-2.0/studio/app.py`: FastAPI API, profile consent/settings, audio imports/evaluation, generation/conversion routes, edit previews, ratings, backup/restore, host/origin/session protection and system/storage reports.
- `studio/engine.py`: Chatterbox Original/Expressive, Chatterbox Turbo and Seed-VC adapters; CPU/CUDA selection, conditioning cache, unloading and Auto OOM fallback.
- `studio/models.py`: official Chatterbox model repositories, required filenames, download/verification and per-install manifests.
- `studio/seed_assets.py`, `studio/seed.py`, `studio/seed_vendor/`: shared Seed assets, recorded/live conversion and experimental final-head adaptation; upstream source/license notices retained.
- `studio/jobs.py`: persistent serialized inference worker, segmented speech, batch generation, progress, cancellation, retries, adaptation and hardware benchmark jobs.
- `studio/audio.py`: decode/encode helpers and FFmpeg processing for pitch, speed, trimming and noise reduction. FFmpeg is taken from PATH or imageio-ffmpeg.
- `studio/live.py`: authenticated local WebSocket Float32 audio transport; benchmark-gated streaming, permission checks and bounded output.
- `studio/static/index.html`, `style.css`, `app.js`, `dashboard.js`, `seed.js`, `live-worklet.js`: complete browser interface, forms, profile cards, microphone recording/gain, waveforms/meters, playback/preview, speech/conversion controls and streaming UI. No frontend compilation, Node build or separate frontend server is required. Design uses CSS, text/icons and user-supplied profile photos; personal photos are not included.
- `studio/__main__.py`: local entry point, cache/temp setup, existing-session detection, Windows browser opening and Uvicorn server.
- `studio/backup.py`, `persistence.py`: private checksum ZIP backup/restore and optional external private backup integration.
- `studio/system.py`: hardware/storage reports. `scripts/diagnostics.py`: read-only diagnostic entry point.
- `Open Studio 2.0.cmd`, `Install Studio 2.0.cmd`, `Start Studio 2.0.cmd`, `Studio 2.0 Diagnostics.cmd`, `scripts/bootstrap.py`, `scripts/check_installation.py`: existing Windows installation and launch system.
- `requirements*.txt`: app/engine/dev dependencies and the captured full Linux CPU dependency lock.
- `Dockerfile`, `.dockerignore`, `studio/hosted.py`, `scripts/deploy_space.py`: optional hosting code, preserved but not used for ordinary local launch.
- `tests/`: backend regression tests and opt-in browser/real-inference scripts. Some inference scripts assume cloud paths and explicitly synthetic QA references; do not blindly run them against personal data.
- `docs/VALIDATION.md`, `ENGINE-EVALUATION.md`, `FEATURE-CHECKLIST.md`: existing recorded verification and limits.
- `browser/`: earlier standalone offline library companion, explicitly not the full neural app.

## Chatterbox Turbo connection

Both Original and Turbo are provided by **chatterbox-tts 0.1.7**; there is no separately installed `Chatterbox Turbo` Python package/version here.

1. The workspace `workspace-engine` selector in `dashboard.js` saves `engine: 'turbo'` in the selected profile through PATCH `/api/profiles/{id}`. The profile editor also supports this selection.
2. Generate Speech posts text/settings to `/api/profiles/{id}/generate`; `app.py` enforces authorization, checks availability and calls `Jobs.submit`.
3. `jobs.py` splits long text and calls `VoiceEngine.synthesize` with the current selected profile reference.
4. `engine.py` imports `ChatterboxTurboTTS` from `chatterbox.tts_turbo`, verifies the local `shared-models/turbo` directory, calls `ChatterboxTurboTTS.from_local`, prepares the reference conditionals and calls `generate` under torch inference mode.
5. Output is stored in that profile's generated-audio directory, indexed in its history, played by browser audio controls and exported via WAV/MP3 API routes.

Turbo supports English here and requires a reference longer than five seconds. Temperature applies; Original's exaggeration/CFG controls are not sent to Turbo. `expressive` maps to `ChatterboxTTS` from `chatterbox.tts`. Original's shared S3 generator also supports recorded conversion through `ChatterboxVC`. Seed is a separate conversion/adaptation engine; it is not Turbo speech generation. Upstream Chatterbox watermark runtime checks remain intact.

## Existing installation and downloads: actual behavior

The model installation is built into the bundled **Windows launcher/bootstrap workflow**, not an in-browser model download/install button. The browser reports engine availability and provides engine/settings/unload controls; it does not install Python/packages/models itself. Preserve this distinction when simplifying the app.

`Open Studio 2.0.cmd` checks `.venv-ai\Scripts\python.exe` and calls `scripts/check_installation.py`. If incomplete it invokes `py -3.11 scripts\bootstrap.py`, then starts `.venv-ai\Scripts\python.exe -m studio`. `Install Studio 2.0.cmd` invokes the same bootstrap explicitly. `Start Studio 2.0.cmd` expects the environment to exist.

Bootstrap creates the separate environment, chooses torch/torchaudio 2.6.0 CUDA 12.4 wheels if Windows `nvidia-smi` succeeds (otherwise CPU), installs `requirements-engine.txt`, runs pip check, verifies existing shared models, downloads missing/invalid official models and Seed assets, and reuses valid weights. Public-model downloads do not require the optional hosting credentials. First installation needs network access and preinstalled 64-bit Python 3.11 with the `py` launcher.

`models.py` retrieves official Hugging Face metadata, selects that repository revision, verifies SHA-256 for large LFS files and Git blob hashes for small files, then writes revision/hash/size manifests. Runtime verifies manifests before loading. Original/Turbo download metadata currently tracks upstream at download time rather than having source-pinned revisions; the captured installed revisions are in `DEPENDENCY-SNAPSHOT.json`. Seed revisions are pinned in `seed_assets.py`.

The original `scripts/bootstrap.py` download root uses `STUDIO2_DATA_DIR/shared-models`; runtime/check_installation also recognize `STUDIO2_MODEL_DIR`. A custom separate model directory therefore requires developer attention; this existing difference has not been repaired in this transfer.

## Local launch and storage

The browser talks by same-origin HTTP to the local FastAPI/Uvicorn process, which runs PyTorch directly in the same application process. There is no external voice-generation service to connect to. Live transport uses a local WebSocket. The default listener is `127.0.0.1:8770`; the Windows entry point opens the browser after readiness and reuses an already running Studio session. Keep its console open.

Windows data/model/cache/temp default: `D:\AI-Voice-Cloning-Studio`. The Python environment stays inside the source folder; keep that folder on D: if packages should also stay there. Missing D: requires an explicit data-root override; it does not silently use C:. Linux defaults to the source folder's `.runtime`.

Each UUID profile has separate original-recordings, references, voice-models, samples, generated-audio and settings folders. Shared base engines are stored once outside the profiles. Local defaults do not require a password screen. Optional hosted authentication code is preserved, not removed or activated; do not set hosted environment variables for ordinary local use. `LOCAL-CONFIGURATION.template.txt` lists only non-secret local settings. No actual environment files or secrets are copied.

## Versions and reproducibility

Observed cloud interpreter: **Python 3.11.16**. Windows bootstrap requires Python **3.11**, not that exact patch.

| Dependency | Existing/observed version |
| --- | --- |
| Chatterbox Original and Turbo runtime | chatterbox-tts 0.1.7 |
| PyTorch / torchaudio | 2.6.0; observed cloud wheels 2.6.0+cpu |
| Windows CUDA wheel configuration | cu124 / CUDA 12.4; physical GPU not verified |
| FastAPI / Uvicorn | 0.115.12 / 0.34.2 |
| transformers / huggingface-hub | 5.2.0 / 1.33.0 in recorded environment |
| NumPy / SoundFile | 1.26.4 / 0.13.1 |
| imageio-ffmpeg | 0.6.0 |
| wsproto / munch | 1.3.2 / 4.0.0 |
| Pillow / pytest / httpx | 12.3.0 / 8.3.5 / 0.28.1 |
| setuptools | 78.1.0 engine requirement |

See `requirements-engine-lock.txt` for all captured package versions. That file is a **Linux CPU environment snapshot** and pins `+cpu` torch wheels; do not apply it uncritically to a Windows CUDA installation. The Windows bootstrap pins its primary requirements but does not use the complete Linux lock, so fresh transitive resolution can differ. CUDA 12.4 is the installer configuration, not a GPU tested on this machine. Model weights are deliberately excluded and must be obtained through the existing downloader later.

## Rebuilding/running from source later

Nothing was rebuilt during packaging. These instructions are for the receiving developer.

Windows: extract into a separate directory, install Python 3.11 64-bit with the Windows launcher, then use the included `Open Studio 2.0.cmd` or `Install Studio 2.0.cmd`. Normal launch uses CMD/Python, not PowerShell. Keep the bundled `.cmd` files beside `scripts`, `studio` and all requirement files.

There is **no compiled MSI/EXE installer, Inno Setup script, NSIS script or PyInstaller configuration** in this app. Its installer is the included `.cmd` + Python bootstrap source. There is consequently no existing `setup.exe` build command to document. To reproduce its existing distributable, archive this intact `Studio-2.0` source folder with those launchers and dependencies, excluding virtual environments, `.runtime`, models, personal data and caches. Building a compiled installer would be new development, not a preserved feature.

For a separate Linux CPU developer environment, from `Studio-2.0`:

```sh
python3.11 -m venv .venv-ai
.venv-ai/bin/python -m pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cpu
.venv-ai/bin/python -m pip install -r requirements-engine.txt -c requirements-engine-lock.txt
.venv-ai/bin/python -m pip check
.venv-ai/bin/python -m pytest -q
.venv-ai/bin/python -m studio.models download --root .runtime/shared-models --engine all
.venv-ai/bin/python -m studio.seed_assets download --root .runtime/shared-models
.venv-ai/bin/python -m studio
```

The existing cloud-install.sh assumes `/workspace/voice-cloner/Studio-2.0`; it is retained verbatim rather than rewritten for the recipient's paths. Browser smoke scripts require Playwright/a browser separately. A frontend build is unnecessary. The optional Dockerfile is preserved; this packaging task did not rebuild or deploy it.

## Tested versus untested

These are **prior recorded results**, corroborated by retained test logs and `docs/VALIDATION.md`; application tests were not rerun, installation was not repeated, and live services were not touched for this transfer.

- 29 backend tests previously passed: profile isolation/consent, persistence, actual decoding and WAV/MP3 processing, serialized jobs/cancellation/retries, previews/editing, backup/restore including adaptation checkpoints, and local streaming session/readiness checks.
- Real CPU Original and Turbo reference-conditioned synthesis, actual Original recorded conversion, multi-segment generation, cached conditioning, exports and browser generation/playback workflows passed using synthetic authorized test references.
- The direct workspace Turbo selector test produced 2.32 seconds of audio in 30.14 seconds total job processing including switching/loading; profile reference, adaptation and conversion settings stayed intact. This is not a guaranteed latency benchmark or personal voice-quality assessment.
- Real Seed CPU conversion, two experimental final-head adaptation steps, checksum verification, candidate audition/rating/activation and CPU benchmark rejection passed. Adaptation is not upstream full fine-tuning and does not guarantee better similarity.
- Desktop/mobile dashboard/build label/shortcuts and browser JavaScript checks passed. Synthetic microphone/browser tests are not physical TONOR tests.
- Browser AudioWorklet/WebSocket/playback/cleanup passed using an explicitly synthetic protocol fixture; this does not verify neural CUDA streaming. Real CPU live benchmark was too slow and correctly rejected readiness.
- Actual Windows install/launch, RTX 2060 peak VRAM/fit, hardware CUDA/OOM fallback, physical microphone/output/OBS devices, live neural GPU conversion, personal voice likeness/accent/naturalness and independent guardian verification remain unverified or unavailable. Child voices are locked.
- Earlier Docker/hosted tests in the original validation document apply to earlier code; the final Seed/dashboard build was not separately rebuilt in Docker. Public hosting/private dataset durability were not validated.

## Existing controls and next-version goals

Preserved controls include speech temperature, Original expression/conditioning, segment pauses, pitch and speed post-processing, microphone gain (volume), browser playback volume, reference trim/denoise/speed/pitch, device selection, Seed inference steps/guidance and per-profile settings. There is no separate generated-audio loudness-processing slider in this snapshot. Signal meters and listening ratings are not automatic voice-similarity scores.

The receiving assistant is asked to simplify for YouTube voiceovers while preserving Turbo, recording/cloning, model installation, adjustments, script generation and WAV/MP3 export. Charcoal-gray/black redesign and dedicated fast **5–10 second** preview controls are requested future work, not delivered changes. Existing unsaved-settings auditions generate their supplied script and store the clip; there is no fixed-duration 5–10 second Turbo preview pipeline or speed guarantee. This transfer implements none of the requested redesign.

The app includes GPL-3.0 Seed architecture code and its existing GPL-3.0/Apache notices. Preserve LICENSE and seed_vendor notices; upstream weights/dependencies keep their own licenses. Do not remove Chatterbox, Turbo, the install process or features merely to simplify the UI.
